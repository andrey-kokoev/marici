# A list of contributors

Formalizations were contributed by the following people (listed alphabetically):

- [Abdelrahman Aly Abounegm](https://github.com/aabounegm),
- [Fredrik Bakke](https://github.com/fredrik-bakke),
- [César Bardomiano Martínez](https://github.com/cesarbm03),
- [Jonathan Campbell](https://github.com/jonalfcam),
- [Robin Carlier](https://github.com/robin-carlier),
- [Theofanis Chatzidiamantis-Christoforidis](https://github.com/thchatzidiamantis),
- [Garrett Credi](https://github.com/ddxtanx),
- [Aras Ergus](https://www.aergus.net/),
- [Matthias Hutzler](https://github.com/MatthiasHu),
- [Nikolai Kudasov](https://fizruk.github.io/),
- [Stefano Luneia](https://github.com/sluneia),
- [Kenji Maillard](https://github.com/kyoDralliam),
- [David Martínez Carpena](https://dvmcarpena.com/),
- [Stiéphen Pradal](https://stiephenpradal.github.io/),
- [Nima Rasekh](https://guests.mpim-bonn.mpg.de/rasekh/),
- [Emily Riehl](https://emilyriehl.github.io/),
- [Judah Towery](https://github.com/jjtowery),
- [Florrie Verity](https://github.com/floverity),
- [Tashi Walde](https://www.math.cit.tum.de/en/algebra/personen/walde/), and
- [Jonathan Weinberger](https://sites.google.com/view/jonathanweinberger).

You may see actual contributed commits in the
[Contributors page on GitHub](https://github.com/rzk-lang/sHoTT/graphs/contributors).
